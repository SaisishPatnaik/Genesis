
import asyncio
import random
import sys

import numpy as np
import pygame
import config

from simulation.environment import Environment
from visualization.renderer import Renderer
from visualization.research_page import ResearchPage

from analytics.statistics import (
    export_history,
    research_snapshot
)


async def main():
    if config.RANDOM_SEED is not None:
        random.seed(config.RANDOM_SEED)
        np.random.seed(config.RANDOM_SEED)

    environment = Environment()

    renderer = Renderer()
    research_page = ResearchPage()

    clock = pygame.time.Clock()

    running = True
    paused = False

    simulation_speed = config.SIMULATION_SPEED
    current_page = "LIVE"

    print("PROJECT GENESIS — ARTIFICIAL LIFE SIMULATION")

    while running:
        frame_dt = clock.tick(config.FPS) / 1000.0

        for event in pygame.event.get():

            renderer.handle_event(event)

            if event.type == pygame.QUIT:
                running = False
                continue

            if (
                current_page == "LIVE"
                and renderer.research_button_clicked(event)
            ):
                current_page = "RESEARCH"
                continue

            if (
                current_page == "RESEARCH"
                and research_page.back_button_clicked(
                    event,
                    renderer.screen.get_size()
                )
            ):
                current_page = "LIVE"
                continue

            if event.type == pygame.KEYDOWN:

                if event.key in (pygame.K_ESCAPE, pygame.K_q):
                    running = False

                elif event.key == pygame.K_r:
                    current_page = (
                        "RESEARCH"
                        if current_page == "LIVE"
                        else "LIVE"
                    )

                elif event.key == pygame.K_SPACE:
                    paused = not paused

                elif event.key == pygame.K_UP:
                    simulation_speed = min(
                        simulation_speed + config.SPEED_INCREMENT,
                        config.MAX_SIMULATION_SPEED
                    )

                elif event.key == pygame.K_DOWN:
                    simulation_speed = max(
                        simulation_speed - config.SPEED_INCREMENT,
                        config.MIN_SIMULATION_SPEED
                    )

                elif (
                    event.key == pygame.K_TAB
                    and current_page == "LIVE"
                ):
                    renderer.show_hud = not renderer.show_hud

                elif event.key == pygame.K_s:
                    # File export is desktop-only.
                    if sys.platform != "emscripten":
                        path = export_history(environment)
                        print(f"Analytics exported to: {path.resolve()}")

        if not paused:
            environment.update(
                frame_dt * simulation_speed
            )

        if current_page == "LIVE":
            renderer.render(
                environment,
                paused,
                simulation_speed
            )

        else:
            research_page.render(
                renderer.screen,
                environment
            )
            pygame.display.flip()

        # Required to keep the browser responsive.
        await asyncio.sleep(0)

    renderer.close()


if __name__ == "__main__":
    asyncio.run(main())
